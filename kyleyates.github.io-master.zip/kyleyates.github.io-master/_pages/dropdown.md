---
layout: page
title: Resources
nav: true
nav_order: 8
dropdown: true
children:
  - title: CV
    permalink: /assets/pdf/CV.pdf
  - title: divider
  - title: Application Materials
    permalink: /materials/
  - title: divider
  - title: Slides
    permalink: /slides/
---
