---
layout: page
permalink: /materials/
title: Application Materials
description:
nav: false
nav_order: 6
---



For a copy of my CV, please see [here](https://kyleyates.github.io/assets/pdf/CV.pdf).

For a statement on my teaching philosophy, please see [here](https://kyleyates.github.io/assets/pdf/yates_teaching_statement.pdf). Anonymous student evalutions on teaching can be found on my [teaching page](https://kyleyates.github.io/teaching).

For a statement on my research interests, please see my [research page](https://kyleyates.github.io/research).

